###about this dataset
This dataset comes from Kaggle's "Getting Real about Fake News".
Original link here:   
https://www.kaggle.com/mrisdal/fake-news
