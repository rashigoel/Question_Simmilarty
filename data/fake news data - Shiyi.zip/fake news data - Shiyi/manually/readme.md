###about this dataset
I collect these news manually.  
Each file represents 1 news article, the format is:  
Line 1: title  
Line 2: author  
Line 3: fake("f") or true("t")  
Line 4: URL  
Line 5 ~ the end: news content  
  
p.s.   
1.in abcnews.com.co, sometimes it will download software like "vidplayer.dmg" to my computer when I click the news. Maybe this can be useful in the future?  
2.some of the news will keep using the same content, like 26 ~ 29 in fake folder (content are the same while headlines are not)